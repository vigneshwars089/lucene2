﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using Lucene.Net.Documents;
using Lucene.Net.Index;
using Lucene.Net.QueryParsers;
using Lucene.Net.Search;
using Lucene.Net.Store;
using Lucene.Net.Util;
using Lucene.Net.Analysis;
using Lucene.Net.Analysis.Standard;

namespace consolelucene
{
    public class Output
    {
        public string path { get; set; }
        public string loc { get; set; }
        public Output()
        {
            path = "";
            loc = "";
        }
        //Other properties, methods, events...
    }



    class Program
    {
        static void Main(string[] args)
        {
            
            // Get input string from user
            IndexDocuments();
            //Console.WriteLine("Enter a name to search:");
            //string inputParam = Console.ReadLine();

            searchjsondocument("Filter");

        }
        public static void IndexDocuments()
        {
           
            // index path Ex: c:/index  
            string strIndexDir = ConfigurationManager.AppSettings["Lucene_Index_Search_Path"];
            // Lucene.net index Files directory path set Inside project Folder  
            // eg. d:/document files folder  
            string strdirectorypath = ConfigurationManager.AppSettings["Lucene_Index_DirectoryFile_Path"];
            try
            {
                Lucene.Net.Store.Directory indexDir = Lucene.Net.Store.FSDirectory.Open(new System.IO.DirectoryInfo(strIndexDir));
                Analyzer std = new StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_29);
                System.DateTime start = System.DateTime.Now;
                IndexWriter idxw = new IndexWriter(indexDir, std, true, IndexWriter.MaxFieldLength.UNLIMITED);
                string strpath = strdirectorypath;
                string[] filePaths = System.IO.Directory.GetFiles(strpath, "*", SearchOption.AllDirectories);
                foreach (var path in filePaths)
                {
                    var Extension = path.Substring(path.LastIndexOf('.') + 1).ToLower();
                    if(Extension == "pdf")
                   {
                    using (PdfReader reader = new PdfReader(path))
                    {
                        StringBuilder text = new StringBuilder();
                        for (int i = 1; i <= reader.NumberOfPages; i++)
                        {
                            Lucene.Net.Documents.Document doc = new Lucene.Net.Documents.Document();
                            text.Append(PdfTextExtractor.GetTextFromPage(reader, i));
                            // input = input.Substring(input.IndexOf("/"));  
                            var page = "page number" + i;
                            doc.Add(new Field("path", path, Field.Store.YES,
                            Field.Index.ANALYZED));
                            doc.Add(new Field("content", text.ToString(), Field.Store.YES,
                            Field.Index.ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS));
                            doc.Add(new Field("loc", page, Field.Store.YES,
                            Field.Index.ANALYZED));
                            idxw.AddDocument(doc);
                            idxw.Optimize();
                        }
                    }
                    }
                    else
                    {
                       // var txtpath='@'+path;
                        string[] lines = File.ReadAllLines(path);
                        for (int i = 0; i < lines.Length; i++)
                        {
                            Lucene.Net.Documents.Document doc = new Lucene.Net.Documents.Document();
                             var page = "line number" + i;
                             doc.Add(new Field("path", path, Field.Store.YES,
                            Field.Index.ANALYZED));
                              doc.Add(new Field("content", lines[i], Field.Store.YES,
                            Field.Index.ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS));
                              doc.Add(new Field("loc", page, Field.Store.YES,
                            Field.Index.ANALYZED));
                            idxw.AddDocument(doc);
                            idxw.Optimize();
                            
                        }  
                    }


                } // writing new document to the index  
                idxw.Close();
                System.DateTime end = System.DateTime.Now;
                //Response.Output.Write(end.Ticks - start.Ticks + " total milliseconds------Index sucess");  
               // ViewData["message"] = end.Ticks - start.Ticks + "----Total Milliseconds";
                //ViewData["m"] = "success";
            }
            catch
            {
                //Response.Output.Write("Not Indexing");
            }
            //return View();
        }
        public static void searchjsondocument(string searchtext)
        {
            List<Output> SearchList = new List<Output>();
            List<Output> Searchoutput = new List<Output>();
          //  EmployeeModel model = new EmployeeModel();
           // model.List = new List<SearchResults>();
           // ViewBag.UserList = model.List;
            // view Textbox Pass Value  
            string strName = Convert.ToString(searchtext);
          //  TempData["result"] = "";
            if (searchtext != null || searchtext != "")
            {
                //<!--Lucene_Index_Search_Path-->  
                string strIndexDir = ConfigurationManager.AppSettings["Lucene_Index_Search_Path"];
                Lucene.Net.Store.Directory indexDir = Lucene.Net.Store.FSDirectory.Open(new System.IO.DirectoryInfo(strIndexDir));
                Lucene.Net.Index.IndexReader reader = IndexReader.Open(indexDir, true);
                IndexSearcher searcher = new IndexSearcher(reader);
                Analyzer std = new StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_29);
                QueryParser parser = new QueryParser(Lucene.Net.Util.Version.LUCENE_29, "content", std);
                Query query = parser.Parse(strName);
                TopScoreDocCollector collector = TopScoreDocCollector.Create(1000, true);
                searcher.Search(query, collector);
                ScoreDoc[] hits = collector.TopDocs().ScoreDocs;
                for (int i = 0; i < hits.Length; i++)
                {
                    
                    Document hitDoc = searcher.Doc(hits[i].Doc); // getting actual document  
                    //Console.WriteLine(hitDoc.Get("path"));
                    //Console.WriteLine(hitDoc.Get("loc"));
                    SearchList.Add(new Output
                    {
                        path = hitDoc.Get("path"),
                        loc = hitDoc.Get("loc")
                    });
                   // SearchList[i].path = hitDoc.Get("path");
                    //SearchList[i].loc = hitDoc.Get("loc");
                  // output
                   //Console.WriteLine(hitDoc.Get("content"));
                   // Response.Output.Write("path: " + hitDoc.Get("path") + "<br>" + "Content: " + hitDoc.Get("content") + "<br>");
                   // result = result + hitDoc.Get("path") + "#";
                    searcher.Close();
                }
                foreach (Output Search in SearchList)
                {

                  //  bool duplicatefound = false;
                    if (Searchoutput.Count==0)
                    {
                        Searchoutput.Add(Search);
                        continue;
                    }
                    for (int i = 0; i < Searchoutput.Count; i++)
                    {
                        if (Search.path == Searchoutput[i].path)
                        {
                            Searchoutput[i].loc = Searchoutput[i].loc +','+ Search.loc;
                            //duplicatefound = true;
                        }
                        else
                        {
                            Searchoutput.Add(Search);
                        }
                    }
                }

                foreach (Output output in Searchoutput)
                 {
                     Console.WriteLine(output.path);
                     Console.WriteLine(output.loc);
                 }
                Console.Read();
                //if (result.Length > 1)
                //{
                //    //TempData["result"] = result;
                //}
                //else
                //{
                //    //TempData["result"] = "";
                //}

            }
            //return Json(result, JsonRequestBehavior.AllowGet); //return "Search" view to the user   
        }
    }
}
