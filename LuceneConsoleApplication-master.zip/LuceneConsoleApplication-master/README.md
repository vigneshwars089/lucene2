﻿# LuceneConsoleApplication
This C# Console Application contains code to create and search Lucene indexes. This sample application uses Lucene.Net library which was installed using NuGet Package Manager. 

Refer our blog [Use Lucene.Net in for faster data search][sysblog] on Systenics. 

[sysblog]: <https://www.systenics.com/blog/use-lucenenet-in-for-faster-data-search/>